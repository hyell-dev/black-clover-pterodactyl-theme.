#!/usr/bin/env bash
set -Eeuo pipefail

PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
THEME_ID="black-clover"
THEME_DIR="$PANEL_DIR/public/themes/$THEME_ID"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
MARKER="BLACK_CLOVER_THEME_V1"
BACKUP_ROOT="/var/backups/pterodactyl-black-clover"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "Jalankan sebagai root: sudo bash install.sh"
  exit 1
fi

if [[ ! -d "$PANEL_DIR" || ! -f "$WRAPPER" ]]; then
  echo "Panel tidak ditemukan di $PANEL_DIR"
  echo "Jika lokasi panel berbeda: sudo PANEL_DIR=/lokasi/panel bash install.sh"
  exit 1
fi

if ! grep -q 'Pterodactyl' "$WRAPPER"; then
  echo "File wrapper tidak tampak seperti wrapper Pterodactyl. Dibatalkan."
  exit 1
fi

if grep -q "$MARKER" "$WRAPPER"; then
  echo "Tema sudah terpasang. Jalankan uninstall.sh dahulu untuk pemasangan ulang."
  exit 1
fi

echo "Panel: $PANEL_DIR"
echo "Tema : BLACK CLOVER — DARK GRIMOIRE"
read -r -p "Lanjutkan instalasi setelah membuat backup? [y/N] " answer
[[ "$answer" =~ ^[Yy]$ ]] || exit 0

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/$STAMP"
mkdir -p "$BACKUP_DIR"
cp -a "$WRAPPER" "$BACKUP_DIR/wrapper.blade.php"
if [[ -d "$THEME_DIR" ]]; then
  cp -a "$THEME_DIR" "$BACKUP_DIR/theme-assets"
fi
printf '%s\n' "$PANEL_DIR" > "$BACKUP_DIR/panel-dir"

mkdir -p "$THEME_DIR"
cp -a "$SOURCE_DIR/assets/." "$THEME_DIR/"

python3 - "$WRAPPER" "$THEME_ID" "$MARKER" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
theme_id = sys.argv[2]
marker = sys.argv[3]
data = path.read_text()

css = f'\n        <!-- {marker}:CSS -->\n        <link rel="stylesheet" href="/themes/{theme_id}/theme.css?v=1.0.0">\n'
js = f'\n        <!-- {marker}:JS -->\n        <script defer src="/themes/{theme_id}/theme.js?v=1.0.0"></script>\n'

if "</head>" not in data or "</body>" not in data:
    raise SystemExit("Struktur wrapper tidak sesuai; file tidak diubah.")

data = data.replace("</head>", css + "    </head>", 1)
data = data.replace("</body>", js + "    </body>", 1)
path.write_text(data)
PY

chown -R www-data:www-data "$THEME_DIR" 2>/dev/null || true
chmod -R 755 "$THEME_DIR"
cd "$PANEL_DIR"
php artisan view:clear
php artisan cache:clear || true

echo
echo "Instalasi selesai."
echo "Backup wrapper: $BACKUP_DIR/wrapper.blade.php"
echo "Bersihkan cache browser / lakukan hard refresh."
echo "Untuk menghapus tema: sudo bash $SOURCE_DIR/uninstall.sh"
