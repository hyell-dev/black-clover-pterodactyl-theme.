#!/usr/bin/env bash
set -Eeuo pipefail

PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
THEME_ID="black-clover"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
BACKUP_ROOT="/var/backups/pterodactyl-black-clover"

if [[ $EUID -ne 0 ]]; then
  echo "Jalankan sebagai root: sudo bash uninstall.sh"
  exit 1
fi

if [[ ! -f "$WRAPPER" ]]; then
  echo "Wrapper tidak ditemukan: $WRAPPER"
  exit 1
fi

BACKUP=""
for candidate in "$BACKUP_ROOT"/*; do
  [[ -d "$candidate" && -f "$candidate/wrapper.blade.php" ]] || continue
  saved_panel="$(cat "$candidate/panel-dir" 2>/dev/null || true)"
  [[ "$saved_panel" == "$PANEL_DIR" ]] && BACKUP="$candidate"
done

if [[ -z "$BACKUP" ]]; then
  echo "Backup tidak ditemukan. Tidak ada file yang diubah."
  exit 1
fi

read -r -p "Pulihkan wrapper dari $BACKUP dan hapus aset tema? [y/N] " answer
[[ "$answer" =~ ^[Yy]$ ]] || exit 0

cp -a "$BACKUP/wrapper.blade.php" "$WRAPPER"
rm -rf "$PANEL_DIR/public/themes/$THEME_ID"
cd "$PANEL_DIR"
php artisan view:clear
php artisan cache:clear || true

echo "Tema dihapus dan wrapper dipulihkan dari backup."
