/* BLACK CLOVER — DARK GRIMOIRE | safe UI-only enhancements */
(() => {
  'use strict';
  if (window.__BLACK_CLOVER_THEME__) return;
  window.__BLACK_CLOVER_THEME__ = true;

  const ready = (fn) => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, { once: true });
    else fn();
  };

  ready(() => {
    const ambient = document.createElement('div');
    ambient.id = 'bc-ambient';
    document.body.prepend(ambient);

    // Optional cinematic layer on the dashboard only; muted, decorative, and disabled on small screens.
    if ((location.pathname === '/' || location.pathname === '') &&
        window.matchMedia('(min-width: 900px)').matches &&
        !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      const cinematic = document.createElement('div');
      cinematic.id = 'bc-cinematic';
      cinematic.setAttribute('aria-hidden', 'true');
      cinematic.innerHTML = '<iframe src="https://www.youtube-nocookie.com/embed/Y7sQPj1moTw?autoplay=1&mute=1&controls=0&loop=1&playlist=Y7sQPj1moTw&playsinline=1&modestbranding=1" title="Black Clover official trailer ambience" loading="lazy" allow="autoplay; encrypted-media" tabindex="-1"></iframe>';
      document.body.prepend(cinematic);
    }

    const progress = document.createElement('div');
    progress.id = 'bc-progress';
    document.body.appendChild(progress);

    const widget = document.createElement('aside');
    widget.id = 'bc-widget';
    widget.innerHTML = `
      <section id="bc-widget-panel" aria-label="Grimoire quick panel">
        <div class="bc-widget-head">
          <div><div class="bc-widget-kicker">Black Clover / Grimoire</div><div class="bc-widget-clock" id="bc-clock">--:--:--</div><div class="bc-widget-date" id="bc-date">Loading date…</div></div>
          <span aria-hidden="true" style="font-size:25px;color:#bba5f3">✦</span>
        </div>
        <div class="bc-widget-status"><i class="bc-dot"></i><span>Panel interface active</span></div>
        <nav class="bc-widget-links">
          <a href="/">Dashboard</a><a href="/account">Account</a>
          <a href="/account/api">API credentials</a><a href="https://pterodactyl.io/" target="_blank" rel="noopener">Documentation ↗</a>
        </nav>
        <div class="bc-widget-foot">Visual companion · Does not change server processes</div>
      </section>
      <button id="bc-widget-toggle" type="button" aria-expanded="false"><span>✧</span><span>GRIMOIRE WIDGET</span></button>
    `;
    document.body.appendChild(widget);

    const panel = document.getElementById('bc-widget-panel');
    const toggle = document.getElementById('bc-widget-toggle');
    toggle.addEventListener('click', () => {
      const open = panel.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });

    const clock = document.getElementById('bc-clock');
    const date = document.getElementById('bc-date');
    const updateClock = () => {
      const now = new Date();
      clock.textContent = new Intl.DateTimeFormat(undefined, {
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
      }).format(now);
      date.textContent = new Intl.DateTimeFormat(undefined, {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
      }).format(now);
    };
    updateClock();
    window.setInterval(updateClock, 1000);

    let ticking = false;
    const updateProgress = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = (max > 0 ? Math.min(100, (window.scrollY / max) * 100) : 0) + '%';
      ticking = false;
    };
    window.addEventListener('scroll', () => {
      if (!ticking) { window.requestAnimationFrame(updateProgress); ticking = true; }
    }, { passive: true });
    updateProgress();

    // Gentle pointer depth on wide screens only; no layout or click interception.
    if (window.matchMedia('(hover:hover) and (pointer:fine)').matches &&
        !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      document.addEventListener('pointermove', (event) => {
        const x = (event.clientX / window.innerWidth - .5) * 2;
        const y = (event.clientY / window.innerHeight - .5) * 2;
        ambient.style.transform = `translate3d(${x * -3}px, ${y * -3}px, 0)`;
      }, { passive: true });
    }
  });
})();
