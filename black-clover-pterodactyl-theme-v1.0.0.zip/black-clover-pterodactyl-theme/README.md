# BLACK CLOVER — DARK GRIMOIRE
Custom visual theme for Pterodactyl Panel **v1.15.2**.

## Contents
- `install.sh` — backs up the Blade wrapper, installs CSS/JS, clears Laravel view/cache.
- `uninstall.sh` — restores the latest matching wrapper backup and removes theme assets.
- `assets/theme.css` — dark minimalist styling, ambient depth, responsive widget.
- `assets/theme.js` — clock/date quick panel, scroll progress, restrained pointer depth.

## Install
Upload and extract this folder to the VPS, then run:

```bash
cd black-clover-pterodactyl-theme
sudo bash install.sh
```

Default panel directory: `/var/www/pterodactyl`

For a custom directory:

```bash
sudo PANEL_DIR=/your/panel/path bash install.sh
```

## Uninstall

```bash
sudo bash uninstall.sh
```

## Notes
- This is a UI customization for Pterodactyl 1.15.2, not a Pterodactyl 2.x native theme.
- The installer only adds stylesheet/script references to `resources/views/templates/wrapper.blade.php` and copies assets to `public/themes/black-clover`.
- It does not change authentication, API routes, database, Docker, Wings, server settings, or resource values.
- The widget displays local time and navigation shortcuts. It does not invent CPU/RAM metrics or claim to monitor host processes.
- Character artwork uses an image hosted by the official Black Clover website: `https://bclover.jp/en/assets/img/top/visual/thumb_visual2.jpg`.
- On the desktop dashboard only, a muted decorative trailer ambience uses the official Crunchyroll trailer embed `Y7sQPj1moTw`. It is disabled on small screens and when reduced-motion is preferred. Video availability and embed permissions are controlled by YouTube/Crunchyroll; if it does not load, the rest of the theme still works.
- Remote media requires an internet connection. Respect the copyright and terms of the respective rights holders.
- A panel update may replace the wrapper file. Re-run the installer after reviewing the new wrapper, or restore with `uninstall.sh` before updating.
